package project.gradproject.domain.store;

public enum StoreStatus {
    CLOSED, OPEN
}
