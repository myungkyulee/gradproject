package project.gradproject.domain.waiting;

public enum WaitingStatus {
    WAIT, ENTER
}
