package project.gradproject.domain.store;

public class Menu {


}
