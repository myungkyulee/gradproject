package project.gradproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
